// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// 引入 ERC721 標準
import "@openzeppelin/contracts/token/ERC721/ERC721.sol";
// 引入處理 tokenURI 存儲的擴展
import "@openzeppelin/contracts/token/ERC721/extensions/ERC721URIStorage.sol";
// 引入權限控制 (合約擁有者)
import "@openzeppelin/contracts/access/Ownable.sol";

// 合約繼承 ERC721URIStorage (包含 _setTokenURI) 和 Ownable
contract CertificateNFT is ERC721URIStorage, Ownable {
    // 下一個可用的 Token ID，從 0 開始
    uint256 private _nextTokenId; 

    // 建構子
    constructor(string memory name, string memory symbol)
        ERC721(name, symbol) 
        Ownable(msg.sender) 
    {
        _nextTokenId = 0;
    }

    // 鑄造證書 NFT 的核心函式
    function mintCertificate(address recipient, string memory metadataURI) // 將 tokenURI 改為 metadataURI
        public
        onlyOwner 
        returns (uint256)
    {
        uint256 tokenId = _nextTokenId;
        
        // 更新計數器：$N_{next} = N_{current} + 1$
        _nextTokenId++;
        
        // 鑄造 NFT 給學生
        _safeMint(recipient, tokenId); 
        
        // 設定 NFT 的 Metadata 連結
        _setTokenURI(tokenId, metadataURI); // 這裡也要跟著改
        
        return tokenId;
    }

    // 覆寫 tokenURI 函式
    function tokenURI(uint256 tokenId)
        public
        view
        override(ERC721URIStorage) // 只覆寫 ERC721URIStorage
        returns (string memory)
    {
        require(tokenId < _nextTokenId, "Token does not exist."); 
        return super.tokenURI(tokenId);
    }
}